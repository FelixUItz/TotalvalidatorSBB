/*
  Copyright (c) Total Validator.
  All Rights Reserved.
  Use is subject to the terms of the licence.
*/
var pageName = "." + window.location.pathname.split("/").pop();
var sentCheck = false;

//Corrected spelling mistakes
function correctSpelling(word) {
  document.querySelectorAll("span.addword").forEach(function(aw) {
    var gparent,
        kid, kids, gkids, ggkids,
        i, j, k,
        dw = aw.getAttribute("data-word");

    if (dw && dw.toLowerCase() == word.toLowerCase()) {
      aw.removeEventListener("click", sendWords);
      aw.classList.remove("addword");
      if (aw.parentNode) aw.parentNode.classList.remove("error");
      if (aw.nextElementSibling) aw.nextElementSibling.remove();

      //Remove the "spelling mistake" error if there are no more spelling mistakes in this text
      gparent = aw.parentNode.parentNode;
      if (getChildren(gparent, ".error").length === 0) {
        kids = getChildren(gparent.previousElementSibling, ".hoverparent");
        for (i=0;i<kids.length;i++) {
          gkids = kids[i].children;
          if (gkids) {
            for (j=0;j<gkids.length;j++) {
              ggkids = getChildren(gkids[j], ".problem");
              for (k=0;k<ggkids.length;k++) {
                kid = ggkids[k];
                kid.classList.remove("problem");
                kid.textContent = "Spell Check: Mistakes corrected";
                kid = getNext(kid, ".hoverblock");
                if (kid) kid.remove();
              }
            }
          }
        }
      }
      //Same as above for attribute spelling mistakes
      gparent = getParent(aw.parentNode, ".problem");
      if (gparent && getChildren(gparent, ".error").length === 0) {
        gparent.classList.remove("problem");
        gparent.textContent = "Spell Check: Mistakes corrected";
        gparent = getNext(gparent, ".hoverblock");
        if (gparent) gparent.remove();
      }
    }
  });
}
function getParent(el, selector) {
  var parentEl = el.parentNode;
  if (!selector || (parentEl && parentEl.matches(selector))) {
    return parentEl;
  }
  return null;
}
function getNext(el, selector) {
  var nextEl = el.nextElementSibling;
  if (!selector || (nextEl && nextEl.matches(selector))) {
    return nextEl;
  }
  return null;
}
function getChildren(el, selector) {
  var children = [],
      kid;
  if (el) {
    var kids = el.children;
    if (kids) {
      for (var i = 0; i < kids.length; i++) {
        kid = kids[i];
        if (!selector || (kid && kid.matches(selector))) children.push(kid);
      }
    }
  }
  return children;
}

//Send word to Pro Tool
function sendWords(e) {
  var word = this.getAttribute("data-word");
  var req = new XMLHttpRequest();
  req.open("GET", "http://127.0.0.1:" + this.getAttribute("data-port") + "/?word=" + word + "&js=true");
  req.onreadystatechange = function() {
    if (req.readyState != 4) { return; }
    try {
      var status = req.status;
      if (status !== 0 && status !== 200) {
        window.alert("Check that the Pro application is running");
      }
      else if (req.responseText) {
        if (req.responseText.indexOf("Word") !== 0) {
          window.alert(req.responseText);
        }
        else if (req.responseText.indexOf("Word") === 0) {
          correctSpelling(word);
        }
      }
      else {
        window.alert("Check that the Pro application is running");
      }
    } catch (e) {
      window.alert("Check that the Pro application is running");
    }
  };
  req.send();
}

//Save to sessionStorage (capture errors with IE using local files)
function saveSetting(setting, value) {
  try {
    sessionStorage.setItem(setting, value);
  } catch(e) {}
}
function getSetting(setting) {
  var value = null;
  try {
    value = sessionStorage.getItem(setting);
  } catch(e) {}
  return value;
}

//Respond to 'More Info' radio button
function showMoreInfoEvt() {
  showMoreInfo(this);
}
function showMoreInfo(button) {
  //Remove 'moreInfo' functions
  document.querySelectorAll("span.hoverparent").forEach(function(hover) {
    hover.removeEventListener("click", moreInfo);
  });
  var value = button.value,
      style;
  if (value == "show") {
    saveSetting("moreinfo" + pageName, "show");
    //Show all 'more info' blocks
    document.querySelectorAll("span.hoverparent span.hoverblock").forEach(function(info) {
      style = info.style;
      style.display = "inline-block";
      style.position = "relative";
      style.border = "1px solid";
      style.maxWidth = "54em";
      style.padding = "5px";
      style.textIndent = "0";
    });
    //Add click to 'problem' text to show/hide more info
    document.querySelectorAll("span.hoverparent").forEach(function(hover) {
      hover.addEventListener("click", moreInfo);
    });
  }
  else if (value == "hover") {
    saveSetting("moreinfo" + pageName, "hover");
    //Make all 'more info' blocks hoverable, by defaulting to common.css settings
    document.querySelectorAll("span.hoverparent span.hoverblock").forEach(function(info) {
      style = info.style;
      style.display = "";
      style.position = "";
      style.border = "";
      style.maxWidth = "";
      style.padding = "";
      style.textIndent = "";
    });
  }
  else if (value == "hide") {
    saveSetting("moreinfo" + pageName, "hide");
    //Hide all 'more info' blocks
    document.querySelectorAll("span.hoverparent span.hoverblock").forEach(function(info) {
      style = info.style;
      style.display = "none";
      style.position = "relative";
      style.border = "1px solid";
      style.maxWidth = "54em";
      style.padding = "5px";
      style.textIndent = "0";
    });
    //Add click to 'problem' text to show/hide more info
    document.querySelectorAll("span.hoverparent").forEach(function(hover) {
      hover.addEventListener("click", moreInfo);
    });
  }
  //Make shortPage match longPage
  var sp = document.getElementById("s"+value);
  if (sp) sp.checked = true;
  document.getElementById(value).checked = true;
}

//Toggle 'More Info' on problems
function moreInfo() {
  var hoverBlockKids = this.children,
      hbKids, kid, i, j;
  for (i=0; i<hoverBlockKids.length; i++) {
    hbKids = getChildren(hoverBlockKids[i], ".hoverblock");
    for (j=0;j<hbKids.length;j++) {
      kid = hbKids[j];
      if (isVisible(kid)) {
        kid.style.display = "none";
      }
      else {
        kid.style.display = "inline-block";
      }
    }
  }
}
function isVisible(el) {
  return !!(el.offsetWidth || el.offsetHeight || el.getClientRects().length);
}

//Run at document load
document.addEventListener("DOMContentLoaded", function() {
  //START: Page load confirmation --------------------------------------
  if (!sentCheck) {
    var portE = document.getElementById("top");
    if (portE) {
      var port = portE.getAttribute("data-port");
      if (!port) port = "9889";
      if (port != "nocheck") {
        //Uninterested in response
        var req = new XMLHttpRequest();
        req.open("GET", "http://127.0.0.1:" + port + "/?loaded=true");
        req.send();
        sentCheck = true;
      }
    }
  }
  //END: Page load confirmation ----------------------------------------

  //START: Tabs --------------------------------------------------------
  var tabElements = document.querySelectorAll('button[role="tab"]');
  if (tabElements.length > 0) {
    var panelElements = document.querySelectorAll('[role="tabpanel"]');
    var activeIndex = 0;
    var activeFocus = 0;

    // Listen to clicks on tabs
    tabElements.forEach(function (tab, index) {
      if (tab.getAttribute("aria-selected") == "true") {
        activeIndex = index;
        activeFocus = index;
      }

      tab.addEventListener("click", function(e) {
        setActiveTab(index);
      });
      tab.addEventListener("keydown", function(e) {
        var lastIndex = tabElements.length - 1;

        if (e.code === "ArrowLeft" || e.code === "ArrowUp") {
          e.preventDefault();
          if (activeFocus === 0) {
            activeFocus = lastIndex; // First element, jump to end
          }
          else {
            activeFocus = activeFocus - 1; // Move left
          }
          tabElements[activeFocus].focus();
        }
        else if (e.code === "ArrowRight" || e.code === "ArrowDown") {
          e.preventDefault();
          if (activeFocus === lastIndex) {
            // Last element, jump to beginning
            activeFocus = 0;
          } else {
            activeFocus = activeFocus + 1; // Move right
          }
          tabElements[activeFocus].focus();
        }
        else if (e.code === "Home") {
          e.preventDefault();
          activeFocus = 0; // Move to beginning
          tabElements[activeFocus].focus();
        }
        else if (e.code === "End") {
          e.preventDefault();
          activeFocus = lastIndex; // Move to end
          tabElements[activeFocus].focus();
        }
      });
    });
  }

  function setActiveTab(index) {
    // Make currently active tab inactive
    tabElements[activeIndex].setAttribute("aria-selected", "false");
    tabElements[activeIndex].tabIndex = -1;

    // Set the new tab as active
    tabElements[index].setAttribute("aria-selected", "true");
    tabElements[index].tabIndex = 0;
    tabElements[index].focus();

    setActivePanel(index);
    activeIndex = index;
    activeFocus = index;
  }

  function setActivePanel(index) {
    // Hide currently active panel
    panelElements[activeIndex].classList.add('hidetab');
    panelElements[activeIndex].tabIndex = -1;

    // Show the new active panel
    panelElements[index].classList.remove('hidetab');
    panelElements[index].tabIndex = 0;
  }
  //END: Tabs ----------------------------------------------------------

  //START: Summary page result sorting functions -----------------------
  //Respond to 'Sort By' radio button
  function sortResultsEvt() {
    //Check if anything to do
    if (getSetting("sortby") != this.value)
      sortResults(this);
  }
  function sortResults(button) {
    var results = origOrder,
        items = getChildren(document.getElementById("results"), "li"),
        resultsEl = document.getElementById("results");

    //Sort the results by path
    if (button.value == "srtpath") {
      results = sortByPath(items);
      saveSetting("sortby", "srtpath");
    }
    //Sort with most issues at the top
    else if (button.value == "srtmost") {
      results = sortByIssues(items, true);
      saveSetting("sortby", "srtmost");
    }
    //Sort with most issues at the bottom
    else if (button.value == "srtleast") {
      results = sortByIssues(items, false);
      saveSetting("sortby", "srtleast");
    }
    //Unsort them (ie original order)
    else {
      saveSetting("sortby", "srtlinks");
    }
    results.forEach(function(e){resultsEl.appendChild(e);});
  }

  //Sort By Path function
  function sortByPath(items) {
    items.sort(function(a, b) {
      var at = a.textContent,
          bt = b.textContent;

      if (at > bt) return 1;
      else if (at < bt) return -1;
      return 0;
    });
    return items;
  }

  //Sort By Issues function
  function sortByIssues(items, desc) {
    items.sort(function(a, b) {
      var at = a.textContent,
          bt = b.textContent,
          ac = -1,
          bc = -1;

      if (a.getAttribute("data-issues") && b.getAttribute("data-issues")) {
        ac = parseInt(a.getAttribute("data-issues"));
        bc = parseInt(b.getAttribute("data-issues"));
        if (desc) {
          if (ac < bc) return 1;
          else if (ac > bc) return -1;
        }
        else {
          if (ac > bc) return 1;
          else if (ac < bc) return -1;
        }
      }
      //Secondary Sort by Path
      if (at > bt) return 1;
      else if (at < bt) return -1;
      return 0;
    });
    return items;
  }
  //END: Summary page result sorting functions -------------------------

  //START: Spellcheck stuff --------------------------------------------
  //For all browsers, except IE <10
  document.querySelectorAll("body:not([class])").forEach(function() {
    //Build up a list of words on the page, so can check them all at once
    var wordList = "",
        port = 9889;

    //Rewrite the old link into a span, so can add words with a click
    document.querySelectorAll("a.addword").forEach(function(aw) {
      var addWordSpan,
          word = aw.getAttribute("data-word"),
          text = aw.textContent,
          classes = aw.getAttribute("class");

      wordList += word + " ";
      port = aw.getAttribute("data-port");
      addWordSpan = "<span class='" + classes + "' title='Add word to dictionary' data-port='" + port + "' data-word='" + word + "'>" + text + "</span>";
      aw.outerHTML = addWordSpan;
    });

    //Send all the existing words at once, and disable any that are already saved
    if (wordList.length > 0) {
      var req = new XMLHttpRequest();
      req.open("GET", "http://127.0.0.1:" + port + "/?wordlist=" + wordList + "&js=true");
      req.onreadystatechange = function() {
        if (req.readyState != 4) { return; }
        try {
          var status = req.status;
          if (status !== 0 && status !== 200) {
            //Fail silently
          }
          else if (req.responseText) {
            var words = req.responseText.split(" ");
            words.forEach(function (word) {
              correctSpelling(word);
            });
          }
          else {
            //Fail silently
          }
        } catch (e) {
          //Fail silently
        }
      };
      req.send();
    }

    //Process the new spans to add words by clicking
    document.querySelectorAll("span.addword").forEach(function(aw) {
      aw.addEventListener( "click",  sendWords);
    });
  });
  //END: Spellcheck stuff ----------------------------------------------

  //START: Collapsible sections ----------------------------------------
  Array.from(document.getElementsByClassName("nct")).forEach(function(nct) {
    //Restore state of collapsible sections, when redisplay page
    var input = getChildren(nct, 'input')[0],
        subClass = nct.getAttribute("class").split(" ")[1];
    var defaultCollapsed = subClass.indexOf("Col") != -1,
        thisBlock = ".ncb." + subClass,
        page = thisBlock + pageName;

    if (getSetting(page) == "collapsed" ||
        (defaultCollapsed && getSetting(page) != "expanded"))
    {
      if (input.getAttribute("alt")) {
        input.setAttribute("alt", input.getAttribute("alt").replace("Hide", "Show"));
        input.setAttribute("src", "../images/right.svg");
      }
      document.querySelectorAll(thisBlock).forEach(function(tb) {
        tb.style.display = 'none';
      });
      saveSetting(page, "collapsed");
    }
    else {
      if (input.getAttribute("alt")) {
        input.setAttribute("alt", input.getAttribute("alt").replace("Show", "Hide"));
        input.setAttribute("src", "../images/down.svg");
      }
      saveSetting(page, "expanded");
    }
    nct.addEventListener("click", showHide);
  });
  //Show/Hide collapsible sections
  function showHide(e) {
    var thisToggle = this,
        input;
    if (thisToggle.getAttribute("alt")) e.preventDefault();  //Prevent any href firing

    //Get the second class name as the unique 'block' to collapse
    var subClass = thisToggle.getAttribute("class").split(" ")[1];
    var thisBlock = ".ncb." + subClass,
        page = thisBlock + pageName;

    //Toggle the matching element
    var allExpanded;
    if (getSetting(page) == "collapsed") {
      input = getChildren(this, 'input')[0];
      if (input.getAttribute("alt")) {
        input.setAttribute("alt", input.getAttribute("alt").replace("Show", "Hide"));
        input.setAttribute("src", "../images/down.svg");
      }
      saveSetting(page, "expanded");
      allExpanded = true;
    }
    else {
      input = getChildren(this, 'input')[0];
      if (input.getAttribute("alt")) {
        input.setAttribute("alt", input.getAttribute("alt").replace("Hide", "Show"));
        input.setAttribute("src", "../images/right.svg");
      }
      saveSetting(page, "collapsed");
      allExpanded = false;
    }

    //With single issue type letter (EPWI) you must also force all the other controls to match
    if (subClass == "ColE" || subClass == "ColP" || subClass == "ColW" || subClass == "ColI" ||
        subClass == "E" || subClass == "P" || subClass == "W" || subClass == "I") {
      Array.from(document.getElementsByClassName("nct")).forEach(function(nct) {
        var thisToggle = nct;
        var thisSubClass = thisToggle.getAttribute("class").split(" ")[1];
        var thisBlock = ".ncb." + thisSubClass,
            page = thisBlock + pageName;

        //Ignore same one of course
        if (thisSubClass.startsWith(subClass) && thisSubClass != "ColE" && thisSubClass != "ColP" && thisSubClass != "ColW" && thisSubClass != "ColI") {
          //If expanded, make everything else expanded
          if (allExpanded) {
            if (getSetting(page) == "collapsed") {
                thisToggle.click();
            }
          }
          //Make everything else collapsed
          else {
            if (getSetting(page) == "expanded") {
                thisToggle.click();
            }
          }
        }
      });
    }
    //Normal use
    else {
      //Toggle the block between visible and hidden
      document.querySelectorAll(thisBlock).forEach(function(tb) {
        toggle(tb);
        var altText;
        if (isVisible(tb)) {
          if (thisToggle.getAttribute("alt")) {
            altText = thisToggle.getAttribute("alt").replace("Show", "Hide");
            thisToggle.setAttribute("alt", altText);
            thisToggle.setAttribute("src", "../images/down.svg");
          }
          else {
            input = getChildren(tb, 'input')[0];
            if (input.getAttribute("alt")) {
              input.setAttribute("alt", input.getAttribute("alt").replace("Show", "Hide"));
              input.setAttribute("src", "../images/down.svg");
            }
          }
          saveSetting(page, "expanded");
        }
        else {
          if (thisToggle.getAttribute("alt")) {
            altText = thisToggle.getAttribute("alt").replace("Hide", "Show");
            thisToggle.setAttribute("alt", altText);
            thisToggle.setAttribute("src", "../images/right.svg");
          }
          else {
            input = getChildren(tb, 'input')[0];
            if (input.getAttribute("alt")) {
              input.setAttribute("alt", input.getAttribute("alt").replace("Hide", "Show"));
              input.setAttribute("src", "../images/right.svg");
            }
          }
          saveSetting(page, "collapsed");
        }
      });
    }
  }
  function toggle(el) {
    if (el.style.display == 'none') {
      el.style.display = '';
    } else {
      el.style.display = 'none';
    }
  }
  //END: Collapsible sections ------------------------------------------

  //START: Old collapsible sections ----------------------------------------
  Array.from(document.getElementsByClassName("collToggle")).forEach(function(ct) {
    //Restore state of collapsible sections, when redisplay page
    var altText,
        subClass = ct.getAttribute("class").split(" ")[1];
    var defaultCollapsed = subClass.indexOf("Col") != -1,
        thisBlock = ".collBlock." + subClass,
        page = thisBlock + pageName;

    if (getSetting(page) == "collapsed" ||
        (defaultCollapsed && getSetting(page) != "expanded"))
    {
      if (ct.getAttribute("alt")) {
        altText = ct.getAttribute("alt").replace("Hide", "Show");
        ct.setAttribute("alt", altText);
        ct.setAttribute("src", "../images/expand.gif");
      }
      else if (!ct.checked) {
        ct.checked = true;
      }
      document.querySelectorAll(thisBlock).forEach(function(tb) {
        tb.style.display = 'none';
      });
    }
    else {
      if (ct.getAttribute("alt")) {
        altText = ct.getAttribute("alt").replace("Show", "Hide");
        ct.setAttribute("alt", altText);
        ct.setAttribute("src", "../images/contract.gif");
      }
      else if (ct.checked) {
        ct.checked = false;
      }
    }
    ct.addEventListener("click", oldShowHide);
  });
  function oldShowHide(e) {
    //Show/Hide collapsible sections
    var thisToggle = this;
    if (thisToggle.getAttribute("alt")) e.preventDefault();  //Prevent any href firing

    //Get the second class name as the unique 'block' to collapse
    var subClass = thisToggle.getAttribute("class").split(" ")[1];
    var thisBlock = ".collBlock." + subClass,
        page = thisBlock + pageName;

    document.querySelectorAll(thisBlock).forEach(function(tb) {
      toggle(tb);
      var altText;
      if (isVisible(tb)) {
        if (thisToggle.getAttribute("alt")) {
          altText = thisToggle.getAttribute("alt").replace("Show", "Hide");
          thisToggle.setAttribute("alt", altText);
          thisToggle.setAttribute("src", "../images/contract.gif");
        }
        saveSetting(page, "expanded");
      }
      else {
        if (thisToggle.getAttribute("alt")) {
          altText = thisToggle.getAttribute("alt").replace("Hide", "Show");
          thisToggle.setAttribute("alt", altText);
          thisToggle.setAttribute("src", "../images/expand.gif");
        }
        saveSetting(page, "collapsed");
      }
    });
  }
  //END: Old collapsible sections ------------------------------------------

  //START: Summary page result sorting ---------------------------------
  //Save the original order and button for 'unsorting' later
  var origOrder = getChildren(document.getElementById("results"), "li"),
      sortby = getSetting("sortby");

  document.querySelectorAll("[type=radio][name=sortby]").forEach(function(sb) {
    //If no session stored then default to whatever the Tool set
    if (!sortby) {
      if (sb.checked) {
        saveSetting("sortby", sb.value);
        sortResults(sb);
      }
    }
    //Restore session settings
    else if (sb.value == sortby) {
      sb.checked = true;
      sortResults(sb);
    }
    sb.addEventListener("click", sortResultsEvt);
  });
  //END: Summary page result sorting -----------------------------------

  //START: More information toggles ------------------------------------
  //Global stuff
  var globalmi = getSetting("globalmi"),
      moreInfoSetting = getSetting("moreinfo" + pageName),
      lastglobal = getSetting("globalmi" + pageName);

  if (globalmi && (!moreInfoSetting || globalmi != lastglobal)) {
    moreInfoSetting = globalmi;
    saveSetting("globalmi" + pageName, globalmi);
  }

  document.querySelectorAll("[type=radio][name=globalmi]").forEach(function(gmi) {
    //If no session stored then default to whatever the Tool set
    if (!globalmi) {
      if (gmi.checked) {
        saveSetting("globalmi", gmi.value);
      }
    }
    //Restore session settings
    else if (gmi.value == globalmi) {
      gmi.checked = true;
    }
    gmi.addEventListener("click", function() {
      if (this.value == "hover") {
        saveSetting("globalmi", "hover");
      }
      else if (this.value == "show") {
        saveSetting("globalmi", "show");
      }
      else if (this.value == "hide") {
        saveSetting("globalmi", "hide");
      }
    });
  });

  //Page level stuff
  document.querySelectorAll("[type=radio][name=moreinfo]").forEach(function(mi) {
    //If no session stored then default to whatever the Tool set
    if (!moreInfoSetting) {
      if (mi.checked) {
        saveSetting("globalmi" + pageName, mi.value);
        showMoreInfo(mi);
      }
    }
    //Restore session settings
    else if (mi.value == moreInfoSetting) {
      mi.checked = true;
      showMoreInfo(mi);
    }
    mi.addEventListener("click", showMoreInfoEvt);
  });
  //END: More information toggle ---------------------------------------
});
